(defproject lt-groovy "0.0.7"
  :dependencies [[org.clojure/clojure "1.5.1"]]
  :jvm-opts ["-Xmx768m"])

