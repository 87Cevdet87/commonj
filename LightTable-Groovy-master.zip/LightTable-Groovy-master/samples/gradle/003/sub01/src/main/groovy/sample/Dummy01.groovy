package sample

class Dummy01 {
    String name
}