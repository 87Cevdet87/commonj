package sample

class Dummy02 {
    String name
}