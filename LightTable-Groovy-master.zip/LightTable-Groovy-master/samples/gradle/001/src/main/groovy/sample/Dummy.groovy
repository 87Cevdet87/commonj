package sample

class Dummy {
    String name
}